package com.app_3d_model_generator.app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
